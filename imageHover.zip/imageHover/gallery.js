


function uptoDate(t,alt){

    const image1=document.getElementById("image");
   
    image1.innerHTML=`<img src="${t}"/>

    <h1>${alt}</h1>
 
    
    `;
    console.log(alt)



    
}

function unDo(){

    const image1=document.getElementById("image");
    image1.innerHTML=``;    
}